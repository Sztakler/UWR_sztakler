<?php

phpinfo()

?>

<!-- 
    $_SERVER['SERVER_NAME'] - nazwa serwera
    $_SERVER['SERVER_PORT'] - numer portu
    $_SERVER['REQUEST_METHOD'] - metoda requesta
    $_SERVER['SCRIPT_NAME'] - nazwa pliku ze skryptem php
    $_SERVER['HTTP_USER_AGENT'] - informacje o przeglądarce
 -->